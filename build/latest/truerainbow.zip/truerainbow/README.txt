CorsairRGB True Rainbow - Standalone rainbow engine for Corsair RGB keyboards
==========

Launch, and modify the rainbow using the preference window to create a rainbow animation just the way you like it.


Setting True Trainbow to launch on startup
==========

Place the root folder anywhere you like on your system and launch the "startup_add.bat" file. This will tell Windows to launch True Rainbow when starting up your system. If you'd like to remove True Rainbow from startup, launch "startup_remove.bat" instead.

If you move the True Rainbow folder somewhere else on your system, Windows may not be able to find the executable and you'll have to redo the above steps.


zlib/libpng License
==========

Copyright (c) 2015 Nathan Cousins 

This software is provided 'as-is', without any express or implied warranty.
In no event will the authors be held liable for any damages arising from the
use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not claim
that you wrote the original software. If you use this software in a product,
an acknowledgment in the product documentation would be appreciated but is
not required.

2. Altered source versions must be plainly marked as such, and must not be
misrepresented as being the original software.

3. This notice may not be removed or altered from any source distribution.